;(function( $, window, document, undefined ){
    $(document).ready(function(){
        var $container = $('#tfa-masnory');
        if($container.length){
            // initialize
            $container.imagesLoaded( function() {
                $container.masonry({
                    columnWidth: '.tfa-masnory-item',
                    itemSelector: '.tfa-masnory-item'
                });
            });
        }
        
        var $owl = $('#tfa-owl');
        if($owl.length){
            $owl.owlCarousel({
                navigation : false,
                slideSpeed : 300,
                paginationSpeed : 400,
                singleItem : true
            });
        }
    });
})( jQuery, window , document );