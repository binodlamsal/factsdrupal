<?php global $base_url; ?>
<!--[if lt IE 7]>

    <p class="browsehappy">You are using an <strong>outdated</strong> browser. Please <a href="http://browsehappy.com/">upgrade your browser</a> to improve your experience.</p>

<![endif]-->



<!-- Add your site or application content here -->

<div class="tfa-container">

    <header>

        <div class="tfa-header-info">

            <h1 class="hide">Ten Facts Alive .com</h1>

            <div class="container">

                <div class="row">

                    <div class="col-lg-3">

                        <!-- Brand and toggle get grouped for better mobile display -->

                        <a class="navbar-brand" href="<?php echo $base_url; ?>">Brand</a>

                    </div>

                    <div class="col-lg-9">

                        <div class="tfa-add tfa-add-728 pull-right">

                            <a href="<?php echo $base_url; ?>"><img src="<?php echo $base_url; ?>/sites/all/themes/tenfacts/img/tfa-add-728X90.png" alt=""></a>

                        </div>

                    </div>

                </div>

            </div><!-- /.container-fluid -->

        </div>

        <div class="tfa-navbar">

            <nav class="navbar navbar-default" role="navigation">

                <h2 class="hide">Navigation</h2>

                <div class="container">

                    <!-- Brand and toggle get grouped for better mobile display -->

                    <div class="navbar-header">

                      <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">

                        <span class="sr-only">Toggle navigation</span>

                        <span class="icon-bar"></span>

                        <span class="icon-bar"></span>

                        <span class="icon-bar"></span>

                      </button>

                    </div>



                    <!-- Collect the nav links, fotfa, and other content for toggling -->

                    <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">

                        <ul class="nav navbar-nav">
							
						<?php
                        $menu = menu_navigation_links('main-menu');
						foreach($menu as $man) { 
				   	    $classname = str_replace('-', ' ', $man['attributes']['class'][0]);
						  echo "<li class='".$classname."'>". l($man['title'], $man['href'], array('attributes' => array('class' => $class)))."</li>";
				        
						 } ?>
                        </ul>

                        <ul class="nav navbar-nav tfa-navbar-default tfa-social pull-right">

                            <li><a href="#" class="tfa-social-icon tfa-social-icon-fb" title="Facebook"></a></li>

                            <li><a href="#" class="tfa-social-icon tfa-social-icon-tw" title="Twitter"></a></li>

                            <li><a href="#" class="tfa-social-icon tfa-social-icon-li" title="Linkedin"></a></li>

                            <li><a href="#" class="tfa-social-icon tfa-social-icon-gp" title="Google Plus"></a></li>

                        </ul>

                    </div><!-- /.navbar-collapse -->

                  </div><!-- /.container-fluid -->

            </nav>

        </div>

    </header>

    <section class="tfa-content">

        <div class="container">

            <div class="row">

                <section class="col-lg-9">

                   <?php if ($page['masonry']): ?>
                   <?php print render($page['masonry']); ?>
                   <?php endif; ?>
                   
                   <?php //print render($page['content']); ?>

                </section>

                <aside class="col-lg-3">

                   <?php if ($page['random']): ?>
                   <?php print render($page['random']); ?>
                   <?php endif; ?>

                    <div class="tfa-block tfa-block-popular">

                        <h3>Popular on <strong>Tenfactsalive</strong></h3>

                       <?php if ($page['popular']): ?>
					   <?php print render($page['popular']); ?>
                       <?php endif; ?>

                        <!--<div class="tfa-seemore">

                            <a href="#" title="See All">See More <span class="tfa-icon tfa-icon-link-arrow"></span></a>

                        </div>-->

                    </div>

                    <div class="tfa-block tfa-block-ad">

                        <!--<figure>

                            <img src="http://tenfactsalive.com/sites/all/themes/tenfacts/img/tfa-article-img.png" alt="">

                            <figcaption>

                                Advertisement

                            </figcaption>

                        </figure>-->

                    </div>

                </aside>

            </div>

        </div>

    </section>

    <footer>

        <div class="container">

            <div class="row">

                <div class="col-lg-8">

                    <p>Copyright <?php echo date('Y'); ?> @ <strong><a href="<?php echo $base_url; ?>" title="ENFACTSALIVE.com">TENFACTSALIVE.com</a></strong></p>

                </div>

                <div class="col-lg-4">

                    <nav class="navbar navbar-default">

                        <ul class="nav navbar-nav tfa-navbar-default pull-right">

                            <li><?php echo l('Contact us', 'node/68'); ?></li>

                            <li><?php echo l('Privacy Policy', 'node/69'); ?></li>

                        </ul>

                    </nav>

                </div>

            </div>

        </div>

    </footer>

</div>