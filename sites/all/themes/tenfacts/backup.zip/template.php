<?php

/**
 * @file
 * template.php
 */

//Theme URLs
define("PATH_CSS", path_to_theme() . "/css/");
define("PATH_JS", path_to_theme() . "/js/");

/*
 * Preprocess function for html.tpl.php 
 */
function tenfactsalive_preprocess_html(&$vars) {
    //Stylesheets
    //Global Stylesheets
    drupal_add_css( 'http://fonts.googleapis.com/css?family=Noto+Sans:400,700,400italic', array(
        'scope' => 'header',
        'weight' => 79
    ));
    //Conditional Stylesheets
    
    
    //Javascripts
    //Global Javascripts
    drupal_add_js('$ = jQuery.noConflict();', array(
        'type' => 'inline',
        'scope' => 'header',
        'weight' => 10
    ));
    
    if(arg(0) == 'user' && !$vars['logged_in']){
        
        //Adding new class
        $vars['classes_array'][] = 'page-body login-page login-form-fall';
        
        //Adding new css/js assets
        drupal_add_js(PATH_JS.'jquery.validate.min.js', array(
            'scope' => 'footer',
            'weight' => 30
        ));
        drupal_add_js(PATH_JS.'neon-login.js', array(
            'scope' => 'footer',
            'weight' => 31
        ));
        
    } else {
        $vars['classes_array'][] = 'page-body';
//        if(arg(1) == 'structure'){
//            drupal_add_css( PATH_JS.'icheck/skins/flat/blue.css', array(
//                'header' => 'header',
//                'weight' => 80
//            ));
//            drupal_add_js(PATH_JS.'icheck/icheck.min.js', array(
//                'scope' => 'footer',
//                'weight' => 30
//            ));
//            drupal_add_js("(function($, window){
//                $('input').iCheck({
//                    checkboxClass: 'icheckbox_flat-blue',
//                });
//                })(jQuery, window);", array(
//                    'type' => 'inline',
//                    'scope' => 'footer',
//                    'weight' => 31
//            ));
//        }
    }
}
//Hooks
function tenfactsalive_js_alter(&$javascript) {
//    echo '<pre>';
//    print_r($javascript);
//    exit();
    //change bootstrap.js path.
    $javascript['//netdna.bootstrapcdn.com/bootstrap/3.0.2/js/bootstrap.min.js']['scope'] = 'header';
    $javascript['//netdna.bootstrapcdn.com/bootstrap/3.0.2/js/bootstrap.min.js']['group'] = 100;
    $javascript['//netdna.bootstrapcdn.com/bootstrap/3.0.2/js/bootstrap.min.js']['weight'] = 0.0055;
}
/*
 * Preprocess function for page.tpl.php 
 */
function tenfactsalive_preprocess_page(&$vars){
	
}
/*
 * Preprocess function for user-profile.tpl.php 
 */
function tenfactsalive_preprocess_user_profile(&$vars){
	
}
/*
 * Sidebar Navigation theme function override.
 
function tenfactsalive_menu_tree__menu_navigation($vars) {
}

function tenfactsalive_menu_link__menu_navigation($vars) {
}
 */
function tenfactsalive_menu_tree($vars) {
	
	}

function tenfactsalive_menu_link($vars) {

}

/**
 * Override the breadcrumb to allow for a theme delimiter setting.
 */
function tenfactsalive_breadcrumb($vars) {
    $breadcrumb = $vars['breadcrumb'];
    $crumbs = '';
    if (!empty($breadcrumb)) {
        $lastitem = sizeof($breadcrumb);
        $crumbs = '<ol class="breadcrumb bc-3">';
        $a=1;
        foreach($breadcrumb as $value) {
            if ($a != $lastitem){
                if($a == 1) {
                    $crumbs .= '<li class="breadcrumb-'.$a.'"><i class="entypo-home"></i>'.$value.'</li>';
                } else {
                    $crumbs .= '<li class="breadcrumb-'.$a.'">'.$value.'</li>';
                }
                $a++;
            }
            else {
                $crumbs .= '<li class="breadcrumb-active active"><strong>'.$value['data'].'</strong></li>';
            }
        }
        $crumbs .= '</ol>';
    }
    return $crumbs;
}

//Assigning Template
function tenfactsalive_theme($existing, $type, $theme, $path){

}
/*
 * Form Alter
 */
//Login form alter
function tenfactsalive_form_user_login_alter(&$form, &$form_state){
	
}
//Login form alter
function tenfactsalive_form_user_pass_alter(&$form, &$form_state){

}

/*
 * Form Preprocess
 */
//Login form fields to variables
function tenfactsalive_preprocess_user_login(&$vars) {

}
//Forget password form fields to variables
function tenfactsalive_preprocess_user_pass(&$vars) {
	
}

/*
 * Overiding Panels
 */

/*
 * Overiding Tables
 */
function tenfactsalive_table($vars) {
	
}
