/**
 *	Neon Demo Scripts (Demo Theme Only)
 *
 *	Developed by Arlind Nushi - www.laborator.co
 */

;(function($, window, undefined)
{
	"use strict";
	
	$(document).ready(function()
	{
		
	});
	
})(jQuery, window);
