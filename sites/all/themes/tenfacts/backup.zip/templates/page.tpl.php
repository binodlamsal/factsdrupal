<?php global $base_url; ?>
<div class="page-container">	

    <div class="sidebar-menu">

        <header class="logo-env">

            <!-- logo -->
            <div class="logo">
                <?php if ($logo): ?>
                    <a class="logo navbar-btn pull-left" href="<?php print $front_page; ?>" title="<?php print t('Home'); ?>">
                        <img src="<?php print $logo; ?>" alt="<?php print t('Home'); ?>" />
                    </a>
                <?php endif; ?>
            </div>

            <!-- logo collapse icon -->
            <div class="sidebar-collapse">
                <a href="#" class="sidebar-collapse-icon with-animation"><!-- add class "with-animation" if you want sidebar to have animation during expanding/collapsing transition -->
                    <i class="entypo-menu"></i>
                </a>
            </div>


            <!-- open/close menu icon (do not remove if you want to enable menu on mobile devices) -->
            <div class="sidebar-mobile-menu visible-xs">
                <a href="#" class="with-animation"><!-- add class "with-animation" to support animation -->
                    <i class="entypo-menu"></i>
                </a>
            </div>

        </header>

        <?php if (!empty($page['sidebar_first'])): ?>
            <?php print render($page['sidebar_first']); ?>
        <?php endif; ?>

    </div>	
    <div class="main-content">

        <div class="row">

            <!-- Profile Info and Notifications -->
            <div class="col-md-6 col-sm-8 clearfix">

                <ul class="user-info pull-left pull-none-xsm">

                    <!-- Profile Info -->
                    <li class="profile-info dropdown"><!-- add class "pull-right" if you want to place this from right -->

                        <a href="#" class="dropdown-toggle" data-toggle="dropdown">
						<?php if(!empty($account->picture->uri)) { ?>
                            <img src="<?php print image_style_url('profile_small', $account->picture->uri); ?>" alt="" class="img-circle" />
						<?php } else { ?>
						     <img src="<?php echo $base_url; ?>/<?php echo drupal_get_path('theme',$GLOBALS['theme']) ?>/images/default-avatar.jpg" alt="" class="img-circle" />
						<?php	} ?>
						
						<?php print $account->field_firstname['und'][0]['value'] . ' ' . $account->field_lastname['und'][0]['value']; ?>	
						</a>

                        <ul class="dropdown-menu">

                            <!-- Reverse Caret -->
                            <li class="caret"></li>

                            <!-- Profile sub-links -->
                            <li>
                                <?php print l('<i class="entypo-user"></i> ' . t('Profile'), 'user/'.$account->uid, array('html'=>TRUE)); ?>
                            </li>
                            <li>
                                <?php print l('<i class="entypo-pencil"></i> ' . t('Edit Profile'), 'user/'.$account->uid.'/edit', array('html'=>TRUE)); ?>
                            </li>
                        </ul>
                    </li>

                </ul>

                <ul class="user-info pull-left pull-right-xs pull-none-xsm">

                    <!-- Raw Notifications -->
                    <li class="notifications dropdown">

                        <a href="#" class="dropdown-toggle" data-toggle="dropdown" data-hover="dropdown" data-close-others="true">
                            <i class="entypo-globe"></i>
                            <span class="badge badge-info">6</span>
                        </a>

                        <ul class="dropdown-menu">
                            <li class="top">
                                <p class="small">
                                    <a href="#" class="pull-right">Mark all Read</a>
                                    You have <strong>3</strong> new notifications.
                                </p>
                            </li>

                            <li>
                                <ul class="dropdown-menu-list scroller">
                                    <li class="unread notification-success">
                                        <a href="#">
                                            <i class="entypo-user-add pull-right"></i>

                                            <span class="line">
                                                <strong>New user registered</strong>
                                            </span>

                                            <span class="line small">
                                                30 seconds ago
                                            </span>
                                        </a>
                                    </li>

                                    <li class="unread notification-secondary">
                                        <a href="#">
                                            <i class="entypo-heart pull-right"></i>

                                            <span class="line">
                                                <strong>Someone special liked this</strong>
                                            </span>

                                            <span class="line small">
                                                2 minutes ago
                                            </span>
                                        </a>
                                    </li>

                                    <li class="notification-primary">
                                        <a href="#">
                                            <i class="entypo-user pull-right"></i>

                                            <span class="line">
                                                <strong>Privacy settings have been changed</strong>
                                            </span>

                                            <span class="line small">
                                                3 hours ago
                                            </span>
                                        </a>
                                    </li>

                                    <li class="notification-danger">
                                        <a href="#">
                                            <i class="entypo-cancel-circled pull-right"></i>

                                            <span class="line">
                                                John cancelled the event
                                            </span>

                                            <span class="line small">
                                                9 hours ago
                                            </span>
                                        </a>
                                    </li>

                                    <li class="notification-info">
                                        <a href="#">
                                            <i class="entypo-info pull-right"></i>

                                            <span class="line">
                                                The server is status is stable
                                            </span>

                                            <span class="line small">
                                                yesterday at 10:30am
                                            </span>
                                        </a>
                                    </li>

                                    <li class="notification-warning">
                                        <a href="#">
                                            <i class="entypo-rss pull-right"></i>

                                            <span class="line">
                                                New comments waiting approval
                                            </span>

                                            <span class="line small">
                                                last week
                                            </span>
                                        </a>
                                    </li>
                                </ul>
                            </li>

                            <li class="external">
                                <a href="#">View all notifications</a>
                            </li>				</ul>

                    </li>

                </ul>

            </div>


            <!-- Raw Links -->
            <div class="col-md-6 col-sm-4 clearfix hidden-xs">

                <ul class="list-inline links-list pull-right">
                    <li>
                        <?php print $user_logout_href; ?>
                    </li>
                </ul>

            </div>

        </div>

        <hr />
        <?php if (!empty($breadcrumb)): print $breadcrumb; endif;?>
        <?php print render($title_prefix); ?>
        <?php if (!empty($title)): ?>
          <h2><?php print $title; ?></h2>
        <?php endif; ?>
        <?php print render($title_suffix); ?>
        <br />
        <?php print $messages; ?>
        <?php print render($page['content']); ?>
        <!-- Footer -->
        <footer class="main">
            &copy; 2014 <strong>Inspec. Consulting</strong> All Right Reserved.
        </footer>	
    </div>
</div>