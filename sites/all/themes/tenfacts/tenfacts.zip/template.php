<?php
global $base_url;
/**
 * @file
 * template.php
 */

//Theme URLs
define("PATH_CSS", $base_url."/".path_to_theme() . "/css/");
define("PATH_JS", $base_url."/".path_to_theme() . "/js/");
define("PATH_THIRDPARTY", $base_url."/".path_to_theme() . "/thirdparty/");

/*
 * Preprocess function for html.tpl.php 
 */
function tenfacts_preprocess_html(&$vars) {
    
    //Stylesheets
    //Global Stylesheets
    drupal_add_css( 'http://fonts.googleapis.com/css?family=Source+Sans+Pro:200,300,400,600,700,900,200italic,300italic,400italic,600italic,700italic,900italic', array(
        'scope' => 'header',
        'weight' => 0
    ));
	
	 /* drupal_add_css( 'http://fonts.googleapis.com/css?family=Pontano+Sans&subset=latin,latin-ext', array(
        'scope' => 'header',
        'weight' => 0
    ));*/
	
    drupal_add_css(PATH_CSS . 'tfa-theme.css', array('group' => CSS_THEME, 'type' => 'external', 'weight' => '100'));
    

    //Javascript
    drupal_add_js(PATH_THIRDPARTY.'jquery/js/jquery-1.10.2.min.js', array(
        'scope' => 'footer',
        'weight' => 100
    ));
    
    //Masnory
    drupal_add_js(PATH_THIRDPARTY.'masonry/js/imagesloaded.pkgd.min.js', array(
        'scope' => 'footer',
        'weight' => 101
    ));
    drupal_add_js(PATH_THIRDPARTY.'masonry/js/masonry.pkgd.min.js', array(
        'scope' => 'footer',
        'weight' => 102
    ));
    drupal_add_js(PATH_JS . 'tfa-theme.js', array(
        'scope' => 'footer',
        'weight' => 200
    ));
    
    //Owl Slider
    drupal_add_css(PATH_THIRDPARTY . 'owl-carousel/owl.carousel.css', array('scope' => 'header', 'type' => 'external', 'weight' => '200'));
    drupal_add_css(PATH_THIRDPARTY . 'owl-carousel/owl.theme.css', array('scope' => 'header', 'type' => 'external', 'weight' => '201'));
    
    drupal_add_js(PATH_THIRDPARTY . 'owl-carousel/owl.carousel.js', array(
        'scope' => 'footer',
        'weight' => 105
    ));
}

//Hooks
function tenfacts_js_alter(&$javascript) {
    //change bootstrap.js path.
    $javascript['//netdna.bootstrapcdn.com/bootstrap/3.0.2/js/bootstrap.min.js']['scope'] = 'footer';
    $javascript['//netdna.bootstrapcdn.com/bootstrap/3.0.2/js/bootstrap.min.js']['group'] = 100;
    $javascript['//netdna.bootstrapcdn.com/bootstrap/3.0.2/js/bootstrap.min.js']['weight'] = 0.0055;
}

function tenfacts_preprocess_page(&$vars){
	if((arg(0)=='taxonomy') && (arg(1) == 'term')) {
		$vars['theme_hook_suggestions'][] = 'page__taxonomyterm';
	}
}

function get_related_articles($catId){
  $query = db_select('node', 'n');
  $query->fields('n');
  $query->condition('n.type', 'list_parent_article', '=');
  $query->condition('n.status', '1', '=');
  $result = $query->range(0,3)
            ->orderBy('n.nid', 'DESC')
			->execute()
            ->fetchAll();
  
  return $result;
}