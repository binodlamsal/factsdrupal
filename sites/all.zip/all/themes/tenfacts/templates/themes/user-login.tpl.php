<div class="form-group">

    <div class="input-group">
        <div class="input-group-addon">
            <i class="entypo-user"></i>
        </div>
        <?php print $username_field;?>
    </div>

</div>

<div class="form-group">
    <div class="input-group">
        <div class="input-group-addon">
            <i class="entypo-key"></i>
        </div>
        <?php print $password_field;?>
    </div>

</div>

<div class="form-group">
    <?php print $other_fields; ?>
</div>