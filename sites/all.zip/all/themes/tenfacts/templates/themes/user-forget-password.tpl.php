<div class="form-group">

    <div class="input-group">
        <div class="input-group-addon">
            <i class="entypo-mail"></i>
        </div>
        <?php print $email_field;?>
    </div>

</div>

<div class="form-group">
    <?php print $other_fields; ?>
</div>