ReCAPTCHA
=========
URL: https://github.com/google/ReCAPTCHA
Version:
License: BSD
License File: LICENSE

Description:
ReCAPTCHA is a free CAPTCHA service that protect websites from spam and abuse.
This is Google authored code that provides plugins for third-party integration
with ReCAPTCHA.

Local Modifications:
None.
