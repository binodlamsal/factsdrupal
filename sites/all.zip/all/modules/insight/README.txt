// $Id$

CONTENTS OF THIS FILE
---------------------

 * Introduction
 * Installation
 * Additional Information about README file formatting


INTRODUCTION
------------

Current Maintainer: Chris Shattuck <http://drupal.org/user/166383>

This is where you would put an explaination of what the module does and
why it would be needed.


INSTALLATION
------------

This should outline a step-by-step explanation of how to install the
module.

1. Install as usual, see http://drupal.org/node/70151 for further information.


ADDITIONAL INFORMATION ABOUT README FILE FORMATTING
-----------------------------------------

For more examples of README.txt files, see http://drupal.org/node/447604. For
discussion about possible standards, see http://groups.drupal.org/node/14523.